#import <UIKit/UIKit.h>
#import "ABKBaseContentCardCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABKControlTableViewCell : ABKBaseContentCardCell

@end

NS_ASSUME_NONNULL_END
